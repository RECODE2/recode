//File che tiene traccia dei dati relativi alla connessione al database
 module.exports = {
  'connection': {
      'host': 'recode_db',
      'user': 'root',
      'password': 'recode123'
  },
'database': 'vit',
};
